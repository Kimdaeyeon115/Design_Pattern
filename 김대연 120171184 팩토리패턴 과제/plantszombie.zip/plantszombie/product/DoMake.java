package programming.practice.plantszombie.product;

public interface DoMake {
	public abstract void make();
}
