package programming.practice.plantszombie.product;

public interface DoDefense {
	public abstract void defense();
}
