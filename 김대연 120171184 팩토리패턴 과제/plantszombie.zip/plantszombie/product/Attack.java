package programming.practice.plantszombie.product;

public class Attack implements DoAttack {

	@Override
	public void attack() {
		// TODO Auto-generated method stub
		System.out.println("����!");
	}

}
