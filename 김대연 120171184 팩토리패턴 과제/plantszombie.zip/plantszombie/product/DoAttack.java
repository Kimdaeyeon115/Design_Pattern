package programming.practice.plantszombie.product;

public interface DoAttack {
	public abstract void attack();
}
