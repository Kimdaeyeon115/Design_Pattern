package programming.practice.plantszombie.product;

public class AM_Make implements DoMake {

	@Override
	public void make() {
		// TODO Auto-generated method stub
		System.out.println("������ ����!");
	}

}
