package programming.practice.plantszombie;


import programming.practice.plantszombie.product.*;

public class Sunflower extends Plant {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Sunflower~~");
	}

	public Sunflower() {
		this.domake=new AM_Make();
	}
}
