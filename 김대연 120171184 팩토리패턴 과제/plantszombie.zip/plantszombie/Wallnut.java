package programming.practice.plantszombie;

import programming.practice.plantszombie.product.*;

public class Wallnut extends Plant {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Wallnut~~");
	}

	public Wallnut() {
		this.dodefense=new Wal_Defense();
	}


}
