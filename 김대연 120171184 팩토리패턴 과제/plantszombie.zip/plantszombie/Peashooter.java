package programming.practice.plantszombie;

import programming.practice.plantszombie.product.*;

public class Peashooter extends Plant {
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Peashooter~~");
	}
public Peashooter() {
	this.doattack=new Attack_2();
}
}
