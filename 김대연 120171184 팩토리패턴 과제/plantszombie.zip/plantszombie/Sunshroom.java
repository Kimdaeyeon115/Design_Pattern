package programming.practice.plantszombie;

import programming.practice.plantszombie.product.*;

public class Sunshroom extends Plant {
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Sunshroom~~");
	}

	public Sunshroom() {
		this.domake=new PM_Make();
	}
}
