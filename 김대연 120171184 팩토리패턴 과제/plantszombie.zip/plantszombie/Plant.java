package programming.practice.plantszombie;
import programming.practice.plantszombie.*;
import programming.practice.plantszombie.product.*;
public abstract class Plant {
	protected DoAttack doattack;
	protected DoDefense dodefense;
	protected DoMake domake;
	
	public void attack() {
		this.doattack.attack();
	}
	public void defense() {
		this.dodefense.defense();
	}
	public void make() {
		this.domake.make();
	}
	public abstract void display();

}