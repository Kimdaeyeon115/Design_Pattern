package programming.practice.plantszombie;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Plant plant =  new Sunflower();
		plant.display();
		plant.make();
		System.out.println();
		
		plant = new Repeater();
		plant.display();
		plant.attack();
		System.out.println();
		
		plant = new Peashooter();
		plant.display();
		plant.attack();
		System.out.println();
		
		plant = new Wallnut();
		plant.display();
		plant.defense();
		System.out.println();
		
		plant = new TallNut();
		plant.display();
		plant.defense();
		System.out.println();
		
		plant = new Sunshroom();
		plant.display();
		plant.make();
		System.out.println();
	}

}
