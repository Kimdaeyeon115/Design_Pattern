package programming.practice.plantszombie;

import programming.practice.plantszombie.product.*;

public class TallNut extends Plant {
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� TallNut~~");
	}

	public TallNut() {
		this.dodefense=new Tal_Defense();
	}

}
