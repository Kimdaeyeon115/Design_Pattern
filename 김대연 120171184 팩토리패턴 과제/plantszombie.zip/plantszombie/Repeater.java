package programming.practice.plantszombie;

import programming.practice.plantszombie.*;
import programming.practice.plantszombie.product.*;

public class Repeater extends Plant {
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Repeater~~");
	}

	public Repeater() {
		this.doattack=new Attack();
	}
}
