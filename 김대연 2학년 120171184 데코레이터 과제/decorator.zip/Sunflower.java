package programming.practice.plantszombie.decorator;

public class Sunflower extends Plant{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

	
	/*@Override
	public String getShield() {
		// TODO Auto-generated method stub
		return super.getShield();
	}*/

	
}
