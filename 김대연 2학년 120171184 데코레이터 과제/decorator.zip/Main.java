package programming.practice.plantszombie.decorator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlantMain plant = new Pumpkin(
										new Pumpkin(
													new Sunflower()
													)
									);
		plant.takeDamage(1000);
	}

}
