package programming.practice.plantszombie.decorator;

public class Wallnut {

}
