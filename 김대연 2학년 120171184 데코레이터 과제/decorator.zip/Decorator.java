package programming.practice.plantszombie.decorator;

public abstract class Decorator extends PlantMain{
protected PlantMain plantmain;
	
	//public Decorator(Plant plant) {
	//	this.plant=plant;
	//}
	public Decorator(PlantMain plantmain) {
	this.plantmain=plantmain;
	}
}
