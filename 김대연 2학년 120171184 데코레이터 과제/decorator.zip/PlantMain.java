package programming.practice.plantszombie.decorator;

public abstract class PlantMain {
	protected int hp;
	public abstract void takeDamage(int damage);
	public abstract void display();
	

}
