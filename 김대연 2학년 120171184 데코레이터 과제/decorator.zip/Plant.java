package programming.practice.plantszombie.decorator;

public abstract class Plant extends PlantMain{
	/*protected String shield;
	
	public String getShield() {
		return this.shield;
	}*/
	
	
	@Override
	public void takeDamage(int damage) {
		// TODO Auto-generated method stub
		System.out.println(damage + "�Ĺ�");
		hp -= damage;
	}
	
	//public int takeDameage() {
	//	// TODO Auto-generated method stub
	//	return 0;
	//}
}
