package programming.practice.plantszombie.simple;

public class Tallnut extends Plant {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Tallnut");
	}

}
