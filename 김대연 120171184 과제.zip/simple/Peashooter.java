package programming.practice.plantszombie.simple;

public class Peashooter extends Plant {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Peashooter");
	}

}
