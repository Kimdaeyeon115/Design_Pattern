package programming.practice.plantszombie.simple;

public class Sunflower extends Plant {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Sunflower");
	}

}
