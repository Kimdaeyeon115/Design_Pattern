package programming.practice.plantszombie.simple;

public abstract class Plant {
	public abstract void display();
	
}
