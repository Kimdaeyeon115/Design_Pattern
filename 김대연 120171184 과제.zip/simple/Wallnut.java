package programming.practice.plantszombie.simple;

public class Wallnut extends Plant {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Wallnut");
	}

}
