package programming.practice.plantszombie.simple;

public class Repeater extends Plant {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("���� Repeater");
	}

}
